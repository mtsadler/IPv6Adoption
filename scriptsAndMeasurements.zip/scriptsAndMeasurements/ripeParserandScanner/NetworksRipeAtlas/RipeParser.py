import json
from pprint import pprint
import socket

input = '/Users/mike/Desktop/653/IPv6Adoption-master/FacebookIPv6.json'
with open(input) as data_file:
    data = json.load(data_file)
#pprint(data)
myText = data[0]
webServer = myText["dst_name"]
client = myText["from"]
version = myText["af"]
output = input.split(".json")[0]
#output = socket.gethostbyaddr(webServer)[2] + str(version)
print(output)
f = open(output+ '.txt', "w+")
print("client: " + client)
print("server: " + webServer)
print("IPv" + str(version))
#f.write("client: " + client + "\r\n")
#f.write("server: " + webServer + "\r\n")
#f.write("IPv" + str(version) + "\r\n")
hopNumber = 0
medians = 0
averages = 0
skips = 0



if version is 4 or 6:
    #analyzing hops and capturing the RTT for each hop
    for hop in myText["result"]:
        hopNumber = hop["hop"]
        hopData = hop["result"]
        if "rtt" in hopData[0]:
            hopAvgRtt = (hopData[0]["rtt"] +hopData[1]["rtt"] + hopData[2]["rtt"])/3
            hopList = [hopData[0]["rtt"] , hopData[1]["rtt"] , hopData[2]["rtt"]]
            hopList.sort()
            averages = averages + hopAvgRtt
            medians = medians + hopList[1]
            print("average RTT for hop#" + str(hopNumber) + ": " + str(hopAvgRtt))
            print("median RTT for hop#" + str(hopNumber) + ": " + str(hopList[1]))
            #f.write("average RTT for hop#" + str(hopNumber) + ": " + str(hopAvgRtt) + "\r\n")
            #f.write("median RTT for hop#" + str(hopNumber) + ": " + str(hopList[1]) + "\r\n")
        else:
            skips = skips + 1
    print("number of hops: " + str(hopNumber))
    f.write(str(hopNumber) + "\r\n")
    hopNumber = hopNumber - skips
    print("average total RTT: " + str(averages))
    print("median total RTT: " + str(medians))
    print("number of timed hops: " + str(hopNumber))
    print("average RTT per hop: " + str(averages/hopNumber))
    print("median RTT per hop: " + str(medians/hopNumber))
    f.write(str(averages) + "\r\n")
    f.write(str(medians) + "\r\n")
    #f.write("number of timed hops: " + str(hopNumber) + "\r\n")
    #f.write("average: " + str(averages/hopNumber) + "\r\n")
    #f.write("median: " + str(medians/hopNumber) + "\r\n")
    # breaker = False
    #
    # for something in range(1,hopNumber):
    #     hop = myText["result"][something]
    #     hopPosition = hop["hop"]
    #     hopData = hop["result"]
    #     if "icmpext" in hopData[0] and not breaker:
    #         print("Hop#" + str(something+1) + " is the beginning of the tunnel.")
    #         print(str((hopData[0]["rtt"]+hopData[1]["rtt"]+hopData[2]["rtt"])/3) + " is the average time it took to encapsulate the message.")
    #         #f.write("Hop#" + str(something+1) + " is the beginning of the tunnel.\r\n")
    #         #f.write(str((hopData[0]["rtt"]+hopData[1]["rtt"]+hopData[2]["rtt"])/3) + " is the average time it took to encapsulate the message.\r\n")
    #         for tunnelHops in range(something,hopNumber):
    #             if 'icmpext' not in myText["result"][tunnelHops]["result"][0]:
    #                 print("Hop#" + str(tunnelHops+1) + " is the end of the tunnel.")
    #                 #f.write("Hop#" + str(tunnelHops+1) + " is the end of the tunnel.\r\n")
    #                 breaker = True
    #                 break